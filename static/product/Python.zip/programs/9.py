import math

def factorial_decorator(func):
    def inner(n):
        result = 1
        for i in range(1, int(n) + 1):
            result *= i
        return func(result)
    return inner

def sqrt_decorator(func):
    def inner(n):
        return func(math.sqrt(n))
    return inner

@factorial_decorator
@sqrt_decorator
def calculate(n):
	return n

number = int(input("Enter a number: "))

result = calculate(number)
print("Result:", result)