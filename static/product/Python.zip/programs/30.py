import threading

def calculate_square(number):
    print(f"Square of {number}:", number ** 2)
def calculate_cube(number):
    print(f"Cube of {number}:", number ** 3)
if __name__ == "__main__":
    number = int(input("Enter a number: "))
    square_thread = threading.Thread(target=calculate_square, args=(number,))
    cube_thread = threading.Thread(target=calculate_cube, args=(number,))
   
    square_thread.start()
    cube_thread.start()

    square_thread.join()
    cube_thread.join()
    print("Main thread exiting.")