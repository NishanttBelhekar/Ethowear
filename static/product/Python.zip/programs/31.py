import threading as t

def table(x):
    for i in range(11):
        print(f"{x} * {i} = {x*i}")

t1 = t.Thread(target= table, args=(10,))

t1.start()

t1.join()

print("Done")