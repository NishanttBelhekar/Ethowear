class MyClass:
    def __init__(self, name):
        self.name = name

    def __del__(self):
        print(f"{self.name} object is being destroyed")

# Creating instances of MyClass
obj1 = MyClass("Object 1")
obj2 = MyClass("Object 2")

# Deleting one of the objects
del obj1