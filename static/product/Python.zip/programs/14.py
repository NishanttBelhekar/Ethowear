class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

person1 = Person("Steve", 30)

# Adding a dynamic attribute to the instance
person1.location = "Brooklyn"

print(person1.location)  

# Adding dynamic attributes to the class itself
Person.gender = "Male"
Person.height = 200

# Creating another instance of the Person class
person2 = Person("Bruce", 32)

# Accessing the dynamic attributes added to the class
print(person2.gender)  
print(person2.height) 