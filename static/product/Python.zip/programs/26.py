import re

def validate_url(url):
    pattern = r"((http|https)://)(www\.)?[a-zA-Z0-9@:%._\+~#?&//=]{2,256}\.[a-z]{2,6}(\.[a-z]{2,6})?(/[a-zA-Z0-9@:%._\+~#?&//=]*)?"
    p = re.compile(pattern)
    if url is None:
        return False
    if re.search(p, url):
        return True
    else:
        return False

if __name__ == '__main__':
    url = input('Enter the URL to check: ')
    if validate_url(url):
        print("Valid URL")
    else:
        print(f"Invalid URL: {url}")