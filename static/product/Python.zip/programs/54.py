str_input = input("Enter the sentence: ")
for word in str_input.split():
    print(word)