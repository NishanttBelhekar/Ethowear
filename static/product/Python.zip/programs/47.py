import pandas as pd
def sort_keys_descending(dictionary):
  series = pd.Series(dictionary)
  sorted_series = series.sort_values(ascending=False)
  sorted_keys = sorted_series.index.tolist()
  print(sorted_keys)
input_dict = {'a': 10, 'b': 5, 'c': 15, 'd': 20}
sorted_keys = sort_keys_descending(input_dict)