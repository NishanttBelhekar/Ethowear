class MyClass:
    def class_method(cls):
        print("This is a class method")

# Creating an instance of the MyClass class
obj = MyClass()

# Calling the class method using the object
obj.class_method()