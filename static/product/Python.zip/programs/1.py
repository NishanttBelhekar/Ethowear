number = int(input("Enter a number: "))

if number % 2 == 0:
	print(f"{number} is Even")
else:
	print(f"{number} is Odd")
 
if number > 1:
    for i in range(2, int(number ** 0.5) + 1):
        if number % i == 0:
            print(f"{number} is not Prime")
            break
        else:
            print(f"{number} is Prime")
else:
	print(f"{number} is not Prime")