import pandas as pd
df = pd.read_csv("customers.csv")
print(df.head(3))