import pandas as pd
data = {'A':10,'B':20,'C':30}
indexs = ['X','Y','Z','W']
series = pd.Series(data)
print(series)