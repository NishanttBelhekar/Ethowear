class ParentClass:
    def __init__(self, name):
        self.name = name

    def greet(self):
        print(f"Hello, I'm {self.name} from the ParentClass")

class ChildClass(ParentClass):
    def __init__(self, name, age):
        super().__init__(name)  # Calling the __init__ method of the parent class
        self.age = age

    def greet(self):
        super().greet()  # Calling the greet method of the parent class
        print(f"I am {self.age} years old.")

# Creating an instance of the ChildClass
child = ChildClass("Elon Musk", 51)

# Calling the greet method of the ChildClass
child.greet()