import pandas as pd
def diagonal_sum_function(matrix):
  df = pd.DataFrame(matrix)
  diagonal_elements = df.values.diagonal()
  diagonal_sum = diagonal_elements.sum()
  return diagonal_sum
matrix = [
    [3,2,9],
    [4,5,6],
    [7,8,9]
]
sum_diagonal = diagonal_sum_function(matrix)
print("diagonal sum: ",sum_diagonal)