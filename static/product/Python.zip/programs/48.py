first_tuple = ('a','b','c','d')
indices = (0,2,3)
second_tuple = tuple(first_tuple[i] for i in indices)
print(second_tuple)