f = input("Enter filepath along with the name of the file ")

if open(f, "x"):
    print("new file created")
else:
    print("File already exist")