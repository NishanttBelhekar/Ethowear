input_string = input("Enter a string: ")

upper_count = 0
lower_count = 0

for char in input_string:
    if char.isupper():
        upper_count += 1
    elif char.islower():
            lower_count += 1

print("Total uppercase characters:", upper_count)
print("Total lowercase characters:", lower_count)