set_arr1 = {1,2,3,4}
set_arr2 = {1,2,4}
result = set_arr1.intersection(set_arr2)
print(result if len(result)>0 else "No common element")