import numpy as np


arr = np.arange(10)
print(arr)


binary_file = "arr_binary.npy"
np.save(binary_file, arr)
print(f"Array saved to binary file: {binary_file}")


loaded_arr = np.load(binary_file)
print(f"Array loaded from binary file: {loaded_arr}")


text_file = "arr_text.txt"
np.savetxt(text_file, arr)
print(f"Array saved to text file: {text_file}")


loaded_arr = np.loadtxt(text_file)
print(f"Array loaded from binary file: {loaded_arr}")