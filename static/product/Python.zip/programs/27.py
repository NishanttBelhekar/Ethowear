import re

def validate_Integer(string):
    while True:
        try:
            num=int(string)
            print(f"Valid Integer {num} ")
            break
        except ValueError:
            print("Error: Please enter a valid integer")
            break
        
if __name__=="__main__":
    value=validate_Integer(input("Enter an integer number : "))
    print(value)