lst = [1,2,3,4,5,6,7,8,9]


unique_list = list(set(lst))


unique_tuple = tuple(unique_list)


min_num = min(unique_list)
max_num = max(unique_list)
print("min: ",min_num)
print("max: ",max_num)