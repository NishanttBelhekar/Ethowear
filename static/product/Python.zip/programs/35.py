import pymongo

client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["dbinfo"]
customer_collection = db["customer"]

customer_records = [
    {"name": "Rahul Sharma", "cus_id": 1, "doj": "2022-03-01", "address": "42, Patel Nagar, New Delhi", "email": "rahul.sharma@example.com", "mobile_no": "9876543210", "experience": 6},
    {"name": "Priya Desai", "cus_id": 2, "doj": "2020-09-15", "address": "17, Linking Road, Mumbai", "email": "priya.desai@example.com", "mobile_no": "8765432109", "experience": 3},
    {"name": "Aditya Gupta", "cus_id": 3, "doj": "2021-06-01", "address": "25/A, Sardar Patel Road, Bengaluru", "email": "aditya.gupta@example.com", "mobile_no": "7654321098", "experience": 4},
    {"name": "Sneha Rao", "cus_id": 4, "doj": "2018-11-01", "address": "8, Nungambakkam High Road, Chennai", "email": "sneha.rao@example.com", "mobile_no": "9012345678", "experience": 8},
    {"name": "Akash Mehta", "cus_id": 5, "doj": "2023-02-15", "address": "3/B, Alipore Road, Kolkata", "email": "akash.mehta@example.com", "mobile_no": "8901234567", "experience": 1},
    {"name": "Divya Singh", "cus_id": 6, "doj": "2019-07-01", "address": "72, Ameerpet, Hyderabad", "email": "divya.singh@example.com", "mobile_no": "7890123456", "experience": 5},
    {"name": "Rishab Kapoor", "cus_id": 7, "doj": "2022-11-01", "address": "14, Laxmi Nagar, Pune", "email": "rishab.kapoor@example.com", "mobile_no": "6789012345", "experience": 2},
    {"name": "Nisha Malhotra", "cus_id": 8, "doj": "2021-03-15", "address": "29, Anna Nagar, Ahmedabad", "email": "nisha.malhotra@example.com", "mobile_no": "5678901234", "experience": 4},
    {"name": "Arjun Batra", "cus_id": 9, "doj": "2020-05-01", "address": "61, Sector 17, Chandigarh", "email": "arjun.batra@example.com", "mobile_no": "4567890123", "experience": 6},
    {"name": "Sanjana Reddy", "cus_id": 10, "doj": "2018-08-01", "address": "18/2, Banjara Hills, Hyderabad", "email": "sanjana.reddy@example.com", "mobile_no": "3456789012", "experience": 7}
]
customer_collection.insert_many(customer_records)

# Select * from "customer"
all_customers = customer_collection.find()
for customer in all_customers:
    print(customer)

# Search records by specific name
name_to_search = "Rahul Sharma"
matching_customers = customer_collection.find({"name": name_to_search})
print(f"Customers with name '{name_to_search}':")
for customer in matching_customers:
    print(customer)
    
# Delete records by specific customer ID
cus_id_to_delete = 1
result = customer_collection.delete_one({"cus_id": cus_id_to_delete})
print(f"Deleted {result.deleted_count} record(s) with customer ID {cus_id_to_delete}")