from math_operations.basic_operations import add, subtract, multiply, divide
from math_operations.advanced_operations import exponentiate, square_root

print("Basic Operations:")
print("Addition:", add(5, 3))
print("Subtraction:", subtract(5, 3))
print("Multiplication:", multiply(5, 3))
print("Division:", divide(5, 3))

print("\nAdvanced Operations:")
print("Exponentiation:", exponentiate(5, 3))
print("Square Root:", square_root(25))