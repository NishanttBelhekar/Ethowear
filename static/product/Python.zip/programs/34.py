def count_lines(filename):
    try:
        with open(filename, "r") as file:
            line_count = 0
            for line in file:
                line_count += 1
            return line_count
    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)

filename = "source.txt"
num_lines = count_lines(filename)
if num_lines is not None:
    print("Number of lines in", filename, ":", num_lines)