import pandas as pd
exam_data = {
    "name": ["John", "Emma", "David", "Sophia", "James", "Olivia", "Michael", "Isabella", "William", "Ava"],
    "score": [85, 92, 78, 90, 88, 85, 80, 95, 82, 89],
    "attempts": [1, 3, 2, 3, 2, 3, 1, 1, 2, 2],
    "qualify": [True, True, False, True, True, True, False, True, False, True]
}
labels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
df = pd.DataFrame(exam_data,index=labels)
print(df)