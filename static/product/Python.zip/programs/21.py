def add(a, b):
    return a + b
def subtract(a, b):
    return a - b
def calculator(operation, a, b):
    return operation(a, b)

if __name__ == "__main__":
    operation1 = add
    operation2 = subtract
    result1 = calculator(operation1, 5, 3)
    print("Result of addition:", result1)

    result2 = calculator(operation2, 5, 3)
    print("Result of subtraction:", result2)