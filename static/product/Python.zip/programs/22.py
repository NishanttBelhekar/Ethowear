import re

#calculate the digit in string
def digit_in_string(s): 
    digits=re.findall(r'\d', s) 
    for digit in digits:
            print(digit)

num=input("Enter the String: ")
digit_in_string(num)