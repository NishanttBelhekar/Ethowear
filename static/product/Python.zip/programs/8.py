numbers = [10, 20, 30, 40, 50]

average = lambda nums: sum(nums) / len(nums)
print("Average:", average(numbers))