try:
    result = 10 / 0
    print(result)
except ZeroDivisionError as e:
    print("ERROR - ", e)
finally:
    result = 10 / 10
    print(result)