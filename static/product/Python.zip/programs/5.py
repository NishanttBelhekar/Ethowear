number = int(input("Enter a number: "))
limit = int(input("Enter the limit for finding multiples: "))

print(f"Multiples of {number} up to {limit} are:")

for i in range(1, limit + 1):
    if i % number == 0:
        print(i)