class Employee:
    def __init__(self, hours_worked, extra_hours):
        self.hours_worked = hours_worked
        self.extra_hours = extra_hours

    def calculate_gross_pay(self):
        base_pay_per_day = 1500
        hourly_rate = 75
        extra_hourly_rate = 75
        if self.hours_worked >= 8:
            total_pay = base_pay_per_day + (self.extra_hours * extra_hourly_rate)
        else:
            total_pay = (self.hours_worked * hourly_rate) + (self.extra_hours * extra_hourly_rate)
        return total_pay

hours_worked = int(input("Enter the number of hours worked: "))
extra_hours = int(input("Enter the number of extra hours worked: "))
employee = Employee(hours_worked, extra_hours)
gross_pay = employee.calculate_gross_pay()
print(f"Gross pay: ₹{gross_pay}")