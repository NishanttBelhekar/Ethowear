lst = [1,2,3,4,5,6,7,8,9]
chunk_size = len(lst) // 3
chunk1 = lst[:chunk_size]
chunk2 = lst[chunk_size:2 * chunk_size]
chunk3 = lst[2 * chunk_size:]
chunk1 = chunk1[::-1]
chunk2 = chunk2[::-1]
chunk3 = chunk3[::-1]
print(chunk1,chunk2,chunk3)