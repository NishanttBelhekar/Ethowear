import math

class ArcLength:
    def __init__(self, radius, angle):
        self.radius = radius
        self.angle = angle

    def calculate_arc_length(self):
        arc_length = (self.angle / 360) * (2 * math.pi * self.radius)
        return arc_length

radius = 5  
angle = 45  

arc = ArcLength(radius, angle)
result = arc.calculate_arc_length()

print(f"Arc length for radius {radius} and angle {angle} degrees is {result:.2f}")