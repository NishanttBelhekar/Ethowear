import pymongo

client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["dbinfo"]
doctor_collection = db["doctor"]

doctor_records = [
    {"doc_id": 1, "name": "Dr. Rahul Gupta", "hosp_id": 101, "doj": "2018-01-01", "specialty": "Cardiology", "salary": 100000, "exp": 8},
    {"doc_id": 2, "name": "Dr. Priya Singh", "hosp_id": 102, "doj": "2020-03-15", "specialty": "Pediatrics", "salary": 80000, "exp": 5},
    {"doc_id": 3, "name": "Dr. Aditya Sharma", "hosp_id": 103, "doj": "2019-07-01", "specialty": "Orthopedics", "salary": 90000, "exp": 6},
    {"doc_id": 4, "name": "Dr. Sneha Kapoor", "hosp_id": 104, "doj": "2021-11-01", "specialty": "Dermatology", "salary": 85000, "exp": 3},
    {"doc_id": 5, "name": "Dr. Akash Mehta", "hosp_id": 105, "doj": "2022-06-01", "specialty": "Neurology", "salary": 95000, "exp": 2}
]
inserted_ids = doctor_collection.insert_many(doctor_records).inserted_ids
print("Inserted 5 records with IDs:", inserted_ids)

# Update the experience of a doctor
doc_id_to_update = 3
new_exp = 10
result = doctor_collection.update_one({"doc_id": doc_id_to_update}, {"$set": {"exp": new_exp}})
print(f"Updated {result.modified_count} record(s) with doc_id {doc_id_to_update} and new experience {new_exp}")

# Search for the updated record
updated_doctor = doctor_collection.find_one({"doc_id": doc_id_to_update})
print(f"Updated record for doctor with ID {doc_id_to_update}:")
print(updated_doctor)

# Sort documents in ascending order by experience
sorted_doctors = doctor_collection.find().sort("exp", 1)
print("Doctors sorted in ascending order by experience:")
for doctor in sorted_doctors:
    print(doctor)