class Calculator:
	def add(self, a, b=0):
    	    return a + b

calc = Calculator()

# Demonstrate addition with different parameter configurations
print("5 + 3 =", calc.add(5, 3))	# Providing both parameters
print("5 + default =", calc.add(5)) # Using default parameter for b