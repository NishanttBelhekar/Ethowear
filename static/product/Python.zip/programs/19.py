class Product:
    def __init__(self, product_name, rate, quantity):
        self.product_name = product_name
        self.rate = rate
        self.quantity = quantity

    def calculate_discount(self):
        total_order = self.rate * self.quantity
        discount = 0

        if total_order < 10000:
            discount = 0.20
        elif total_order < 50000:
            discount = 0.10  
        else:
            discount = 0.05  

        discount_amount = total_order * discount
        discounted_price = total_order - discount_amount

        return discount_amount, discounted_price

product_name = input("Enter the product name: ")
rate = float(input("Enter the rate: "))
quantity = int(input("Enter the quantity: "))

product = Product(product_name, rate, quantity)
discount_amount, discounted_price = product.calculate_discount()

print(f"Discount amount: ₹{discount_amount:.2f}")
print(f"Discounted price: ₹{discounted_price:.2f}")