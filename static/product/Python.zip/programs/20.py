class BankAccount:
    def __init__(self, account_holder, initial_balance=0):
        self.account_holder = account_holder
        self.balance = initial_balance

    def deposit(self, amount):
        self.balance += amount
        print(f"Deposited ₹{amount}. New balance: ₹{self.balance}")

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
            print(f"Withdrew ₹{amount}. New balance: ₹{self.balance}")
        else:
            print("Insufficient funds.")

    def check_balance(self):
        print(f"Balance for {self.account_holder}: ₹{self.balance}")

account_holder_name = input("Enter the account holder's name: ")
initial_balance = float(input("Enter the initial balance: "))

account = BankAccount(account_holder_name, initial_balance)

while True:
    print("\nChoose operation:")
    print("1. Deposit")
    print("2. Withdraw")
    print("3. Check Balance")
    print("4. Exit")
    choice = int(input("Enter your choice (1/2/3/4): "))

    if choice == 1:
        amount = float(input("Enter the amount to deposit: "))
        account.deposit(amount)
    elif choice == 2:
        amount = float(input("Enter the amount to withdraw: "))
        account.withdraw(amount)
    elif choice == 3:
        account.check_balance()
    elif choice == 4:
        print("Exiting...")
        break
    else:
        print("Invalid choice. Please enter a valid option.")