import re

# Remove white spaces from a string
def remove_spaces(string):
    return re.sub(r'\s+', '', string)
try:
    string_provided = input("Enter a String: ")
    print(f"The Provided string is '{string_provided}'")

    result = remove_spaces(string_provided)
    print("String after white space remove:", result)  # Removed extra comma
except Exception as e:
    print("An error is ",e)