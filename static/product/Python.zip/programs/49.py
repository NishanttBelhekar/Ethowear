same_tuple = (1,1,1,1)
res = len(set(same_tuple))
print("Same" if res>0 else "Not Same")