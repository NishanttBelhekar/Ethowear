import re

def valid_phoneNum(number):
    pattern = r'^(\+91)[-\s]?[6-9]\d{9}$' 
    if re.match(pattern, number):
        return True
    else:
        return False

number = input("Enter your phone number : ")
if valid_phoneNum(number):
    print("Given number is valid")
else:
    print("Given number is not valid")