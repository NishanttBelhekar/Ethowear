def copy_file(source_file, destination_file):
    try:
        with open(source_file, "r") as source:
            contents = source.read()
            with open(destination_file, "w") as destination:
                destination.write(contents)
        print(f"contents copied successfully from {source_file} to {destination_file}")
    except FileNotFoundError as e:
        print("One of the files does not exist.")

copy_file("source.txt", "destination.txt")