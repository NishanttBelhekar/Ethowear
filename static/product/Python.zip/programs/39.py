import numpy as np
arr = np.array([[1,2],[5,6],[7,8]])
print(arr)
#reshape
reshaped_arr = arr.reshape(2,3)
print(reshaped_arr)
#flatten
flatten_arr = arr.flatten()
print(flatten_arr)
#transpose
transposed_arr = arr.transpose()
print(transposed_arr)